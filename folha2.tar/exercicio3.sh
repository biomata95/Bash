#!/bin/bash

for arquivo in $(ls -1 | rev | cut -f 2- -d "." | rev)
do
	ultimo_caractere=${arquivo: -1}
	if [ $ultimo_caractere != "a" ] 
	then
		echo $arquivo
	fi
done