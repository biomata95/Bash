#!/bin/bash

arquivo=$1
$(ps > $arquivo)