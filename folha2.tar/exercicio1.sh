#!/bin/bash

for arquivo in $(ls)
do
	if [[ ${arquivo:0:1} = *[[:digit:]]* ]]	
	then
		echo $arquivo
	fi
done