#!/bin/bash


diretorios=()
diretorioFinal=$1
diretorio1="DiretorioTeste1"
diretorio2="DiretorioTeste2"
diretorios+=($diretorio1)
diretorios+=($diretorio2)

for diretorioCorrente in "${diretorios[@]}"
do
	for arquivos in $(ls $diretorioCorrente)
	do
		nome="${arquivos%.*}"
		echo $nome
		if [ $nome == "oi5" ]
		then
			echo "No diretorio " $diretorioCorrente " tem a palavra " $arquivos
		fi
	done
done

