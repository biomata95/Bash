#!/bin/bash

for diretorio in $(ls /etc)
do
	fim_string=${diretorio:(-2)}
	if [ ${#diretorio} -eq 5 ] && [[ "$fim_string" == ".d" ]]
	then
		echo $diretorio
	fi
done