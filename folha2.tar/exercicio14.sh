#!/bin/bash

usuarios=$(cat /etc/passwd)
echo " "
cont=0
for i in $usuarios
do
	diretorio_home="$(cut -d':' -f6 <<<"$i")"
	diretorio_home_convertido="$(cut -d'/' -f2 <<<"$diretorio_home")"
	if [ $diretorio_home_convertido == "home" ]
	then
		echo $diretorio_home_convertido "<- AKI TEM"
		cont=$((cont+1))
	fi
done
echo "O numero de utilizadores /home eh:" $cont
echo " "

#! TENTA COM O GREP