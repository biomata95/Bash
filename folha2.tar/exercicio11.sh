#!/bin/bash


diretorios=()
diretorioFinal=$1
diretorio1="DiretorioTeste1"
diretorio2="DiretorioTeste2"
diretorios+=($diretorio1)
diretorios+=($diretorio2)
$(mkdir $diretorio1 && touch $diretorio1/arquivoTeste3.txt $diretorio1/arquivoTeste4.txt)
$(mkdir $diretorio2 && touch $diretorio2/oi8.txt $diretorio2/oi5.txt)
$(mkdir $diretorioFinal)

for diretorioCorrente in "${diretorios[@]}"
do
	for arquivos in $(ls -d -1 $diretorioCorrente/**)
	do
		$(cp -r $arquivos $diretorioFinal)
	done
done

