#!/bin/bash

for arquivo in $(ls -1 | rev | cut -f 2- -d "." | rev)
do
	if [ ${#arquivo} -eq 4 ] 
	then
		echo $arquivo
	fi
	#echo $arquivo
done