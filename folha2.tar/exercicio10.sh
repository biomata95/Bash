#!/bin/bash

arquivo=$1
$(who > $arquivo)
$(sort -d < $arquivo)