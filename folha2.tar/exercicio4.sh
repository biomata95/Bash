#!/bin/bash

for arquivo in $(ls)
do
	extensao="${arquivo##*.}"
	menor="${extensao,,}"
	if [ $menor == "png" ] || [ $menor == "jpg" ] || [ $menor == "jpeg" ]
	then
		echo $arquivo
	fi
done