#!/bin/bash

usuarios=$(cat /etc/passwd)
echo " "
echo "Os usuarios que utilizam Bash como shell sao:"
for i in $usuarios
do
	shell_usuario=${i##*/}
	if [ $shell_usuario == "bash" ]
	then
		echo "$(cut -d':' -f5 <<<"$i")"
	fi
done
echo " "