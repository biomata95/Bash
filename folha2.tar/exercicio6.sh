#!/bin/bash

for diretorio in $(ls /etc)
do
	inicio_string=${diretorio:0:2}
	fim_string=${#diretorio}-2:${#diretorio}-1}
	if [ $inicio_string == "rc" ] && [ fim_string == ".d" ]
	then
		echo $diretorio
	fi
done