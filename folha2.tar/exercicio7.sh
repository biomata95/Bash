#!/bin/bash

for diretorio in $(ls /etc)
do
	inicio_string=${diretorio:0:2}
	if [ $inicio_string == "rc" ] && [[ ${diretorio} = *[[:digit:]]* ]]
	then
		echo $diretorio
	fi
done